import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <>
    <div className="home-container">
      <header className="header">
        <h1>Welcome to the Student Management System</h1>
      </header>

      <section className="achievements-section">
        <h2>Our Achievements</h2>
        <ul className="achievements-list">
          <li>Ranked #1 in regional academic performance in 2023.</li>
          <li>Awarded the Best School in Technology Integration.</li>
          <li>Our students have won multiple coding competitions in React and Java.</li>
          <li>Top performers in mathematics olympiads at state and national levels.</li>
        </ul>
      </section>

      <section className="about-section">
        <h2>About Our School</h2>
        <p>
          Our school is committed to providing a holistic education experience,
          fostering both academic excellence and personal growth. We offer a
          wide range of courses and extracurricular activities designed to
          empower students with the skills and knowledge they need for the
          future. Our achievements in academics, technology, and sports speak
          for our dedication and the hard work of our students and faculty.
        </p>
      </section>

    </div>
      <footer className="footer">
        <p>&copy; 2024 Student Management System. All rights reserved.</p>
      </footer>
    </>
  );
};

export default Home;
