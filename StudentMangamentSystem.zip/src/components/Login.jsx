import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom'; 
import axios from 'axios';
import './LoginSignup.css';

const Login = ({ setIsLoggedIn }) => {  // Pass setIsLoggedIn as a prop
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Handle form submission
  const handleLogin = (e) => {
    e.preventDefault();

    // Fetch users from the JSON server
    axios.get('http://localhost:5000/users')
      .then(response => {
        const users = response.data;

        // Find the user by username and password
        const user = users.find(
          u => u.username === formData.username && u.password === formData.password
        );

        if (user) {
          setIsLoggedIn(true);  // Set login state to true
          navigate('/student-management');  // Redirect to student management
        } else {
          setError('Invalid credentials');  // Set error message if user is not found
        }
      })
      .catch(err => {
        console.error("Error fetching users", err);
        setError('Something went wrong, please try again later.');
      });
  };

  return (
    <div className="auth-container">
      <div className="auth-content">
        <h2 className="top-heading">Login</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>} {/* Display error message if any */}
        <form className="auth-form" onSubmit={handleLogin}>
          <label>
            Username:
            <input 
              type="text" 
              name="username" 
              placeholder="Username" 
              value={formData.username} 
              onChange={handleChange} 
              required 
            />
          </label>
          <label>
            Password:
            <input 
              type="password" 
              name="password" 
              placeholder="Password" 
              value={formData.password} 
              onChange={handleChange} 
              required 
            />
          </label>
          <button type="submit">Login</button>
          <p className="signup-link">
            New here? <Link to="/signup">Sign Up</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
