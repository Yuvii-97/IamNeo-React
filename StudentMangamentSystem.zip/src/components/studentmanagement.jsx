import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './StudentManagement.css';

const StudentManagement = () => {
  const [students, setStudents] = useState([]);
  const [newStudent, setNewStudent] = useState({
    name: '',
    age: '',
    email: '',
    course: ''
  });
  const [editStudent, setEditStudent] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/students')
      .then(response => setStudents(response.data))
      .catch(error => console.error('Error fetching students:', error));
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (editStudent) {
      setEditStudent({
        ...editStudent,
        [name]: value
      });
    } else {
      setNewStudent({
        ...newStudent,
        [name]: value
      });
    }
  };

  const handleAddStudent = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/students', newStudent)
      .then(response => {
        setStudents([...students, response.data]);
        setNewStudent({ name: '', age: '', email: '', course: '' });
      })
      .catch(error => console.error('Error adding student:', error));
  };

  // Edit student
  const handleEditStudent = (student) => {
    setEditStudent(student);
  };

  // Update student
  const handleUpdateStudent = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:5000/students/${editStudent.id}`, editStudent)
      .then(response => {
        const updatedStudents = students.map(student => 
          student.id === editStudent.id ? response.data : student
        );
        setStudents(updatedStudents);
        setEditStudent(null);
      })
      .catch(error => console.error('Error updating student:', error));
  };

  const handleDeleteStudent = (id) => {
    axios.delete(`http://localhost:5000/students/${id}`)
      .then(() => {
        setStudents(students.filter(student => student.id !== id));
      })
      .catch(error => console.error('Error deleting student:', error));
  };

  return (
    <div className="student-management-container">
      <h1>Student Management</h1>
      <div className="form-container">
        <h2>{editStudent ? 'Update Student' : 'Register New Student'}</h2>
        <form onSubmit={editStudent ? handleUpdateStudent : handleAddStudent}>
          <label>
            Name:
            <input
              type="text"
              name="name"
              value={editStudent ? editStudent.name : newStudent.name}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Age:
            <input
              type="number"
              name="age"
              value={editStudent ? editStudent.age : newStudent.age}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Email:
            <input
              type="email"
              name="email"
              value={editStudent ? editStudent.email : newStudent.email}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Course:
            <input
              type="text"
              name="course"
              value={editStudent ? editStudent.course : newStudent.course}
              onChange={handleInputChange}
              required
            />
          </label>
          <button type="submit" className="submit-btn">
            {editStudent ? 'Update Student' : 'Register Student'}
          </button>
        </form>
      </div>

      {/* Student List */}
      <div className="student-list">
        <h2>Registered Students</h2>
        <ul>
          {students.map(student => (
            <li key={student.id} className="student-item">
              <p><strong>Name:</strong> {student.name}</p>
              <p><strong>Age:</strong> {student.age}</p>
              <p><strong>Email:</strong> {student.email}</p>
              <p><strong>Course:</strong> {student.course}</p>
              <div className="actions">
                <button onClick={() => handleEditStudent(student)}>Edit</button>
                <button onClick={() => handleDeleteStudent(student.id)} className="delete-btn">Delete</button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default StudentManagement;
