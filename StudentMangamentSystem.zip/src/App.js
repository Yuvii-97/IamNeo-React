import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Login from './components/Login';
import Signup from './components/Signup';
import StudentManagement from './components/studentmanagement';
import './App.css';

function App() {
  // Simulating login state, in a real app you might fetch this from a global store or context
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/student-management" element={
            isLoggedIn ? <StudentManagement /> : <Login setIsLoggedIn={setIsLoggedIn} />
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
